const cardTypes = [
  { name: "Cóndor", symbol: "🦅" },
  { name: "Montaña", symbol: "🏔️" },
  { name: "Dragón", symbol: "🐉" },
  { name: "Caballero", symbol: "🛡️" },
  { name: "Estrella", symbol: "⭐" },
  { name: "Ciudad", symbol: "🏙️" },
];

const board = document.querySelector("#game-board");
const movesDisplay = document.querySelector("#moves");
const timerDisplay = document.querySelector("#timer");
const bestTimeDisplay = document.querySelector("#best-time");
const gameStatus = document.querySelector("#game-status");
const newGameButton = document.querySelector("#new-game");
const playAgainButton = document.querySelector("#play-again");
const winOverlay = document.querySelector("#win-overlay");
const winSummary = document.querySelector("#win-summary");
const bestTimeKey = "ecos-de-santiago-best-time";

let firstCard = null;
let lockBoard = false;
let moves = 0;
let matches = 0;
let elapsedSeconds = 0;
let timerInterval = null;
let mismatchTimeout = null;

function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, "0");
  const remainder = (seconds % 60).toString().padStart(2, "0");
  return `${minutes}:${remainder}`;
}

function shuffle(items) {
  const shuffled = [...items];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function renderBestTime() {
  const bestTime = localStorage.getItem(bestTimeKey);
  bestTimeDisplay.textContent = bestTime === null ? "—" : formatTime(Number(bestTime));
}

function updateTimer() {
  timerDisplay.textContent = formatTime(elapsedSeconds);
}

function startTimer() {
  if (timerInterval !== null) return;
  timerInterval = window.setInterval(() => {
    elapsedSeconds += 1;
    updateTimer();
  }, 1000);
}

function stopTimer() {
  if (timerInterval !== null) {
    window.clearInterval(timerInterval);
    timerInterval = null;
  }
}

function makeCard(type, index) {
  const card = document.createElement("button");
  card.className = "memory-card";
  card.type = "button";
  card.dataset.name = type.name;
  card.dataset.index = String(index);
  card.setAttribute("aria-label", `Carta ${index + 1}: oculta`);
  card.setAttribute("aria-pressed", "false");

  const back = document.createElement("span");
  back.className = "card-back";
  back.setAttribute("aria-hidden", "true");
  back.textContent = "✧";

  const front = document.createElement("span");
  front.className = "card-front";
  front.setAttribute("aria-hidden", "true");

  const symbol = document.createElement("span");
  symbol.className = "card-symbol";
  symbol.textContent = type.symbol;

  const name = document.createElement("span");
  name.className = "card-name";
  name.textContent = type.name;

  front.append(symbol, name);
  card.append(back, front);
  card.addEventListener("click", () => revealCard(card));
  return card;
}

function revealCard(card) {
  if (lockBoard || card.classList.contains("is-revealed") || card.classList.contains("is-matched")) {
    return;
  }

  startTimer();
  card.classList.add("is-revealed");
  card.setAttribute("aria-pressed", "true");
  card.setAttribute("aria-label", `Carta ${Number(card.dataset.index) + 1}: ${card.dataset.name}`);

  if (firstCard === null) {
    firstCard = card;
    return;
  }

  moves += 1;
  movesDisplay.textContent = String(moves).padStart(2, "0");

  if (firstCard.dataset.name === card.dataset.name) {
    firstCard.classList.add("is-matched");
    card.classList.add("is-matched");
    firstCard.disabled = true;
    card.disabled = true;
    matches += 1;
    firstCard = null;
    gameStatus.textContent = matches === cardTypes.length
      ? "¡Todas las parejas encontradas!"
      : `Parejas encontradas: ${matches} de ${cardTypes.length}`;
    if (matches === cardTypes.length) finishGame();
    return;
  }

  lockBoard = true;
  const previousCard = firstCard;
  firstCard = null;
  mismatchTimeout = window.setTimeout(() => {
    for (const hiddenCard of [previousCard, card]) {
      hiddenCard.classList.remove("is-revealed");
      hiddenCard.setAttribute("aria-pressed", "false");
      hiddenCard.setAttribute("aria-label", `Carta ${Number(hiddenCard.dataset.index) + 1}: oculta`);
    }
    lockBoard = false;
    mismatchTimeout = null;
  }, 850);
}

function finishGame() {
  stopTimer();
  const previousBest = localStorage.getItem(bestTimeKey);
  if (previousBest === null || elapsedSeconds < Number(previousBest)) {
    localStorage.setItem(bestTimeKey, String(elapsedSeconds));
    renderBestTime();
  }
  winSummary.textContent = `Completaste el tablero en ${formatTime(elapsedSeconds)} y ${moves} movimientos.`;
  winOverlay.hidden = false;
  playAgainButton.focus();
}

function startNewGame() {
  stopTimer();
  if (mismatchTimeout !== null) {
    window.clearTimeout(mismatchTimeout);
    mismatchTimeout = null;
  }

  const deck = shuffle([...cardTypes, ...cardTypes]);
  board.replaceChildren(...deck.map(makeCard));
  firstCard = null;
  lockBoard = false;
  moves = 0;
  matches = 0;
  elapsedSeconds = 0;
  movesDisplay.textContent = "00";
  updateTimer();
  gameStatus.textContent = `Encuentra las ${cardTypes.length} parejas`;
  winOverlay.hidden = true;
}

newGameButton.addEventListener("click", startNewGame);
playAgainButton.addEventListener("click", startNewGame);

renderBestTime();
startNewGame();
