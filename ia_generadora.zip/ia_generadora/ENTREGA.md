# Entrega: IA generativa y videojuego web

## Bloque 1 — Generación de imágenes con IA

### Análisis de la referencia

- **Elementos:** un caballero con armadura y capa roja montado sobre un dragón oscuro de grandes alas; debajo se ve Santiago y, al fondo, la cordillera nevada.
- **Composición:** formato panorámico. El dragón y el jinete ocupan el centro y la mitad superior; las alas extendidas conducen la mirada hacia los bordes. La ciudad queda en la franja inferior.
- **Colores e iluminación:** azules y grises fríos en el cielo, las montañas y la ciudad, con acentos cálidos rojizos en la capa y las alas. La luz atraviesa las nubes detrás del personaje.
- **Perspectiva y estilo:** vista amplia ligeramente elevada, con sensación de escala épica; fantasía cinematográfica de aspecto realista, alto contraste y muchos detalles.

### Prompts para tres iteraciones

Los siguientes textos están preparados para probarse en una herramienta de generación de imágenes. Aún hay que ejecutar cada prompt y guardar las tres imágenes generadas como evidencia.

**Intento 1 — composición general**

> Ilustración de fantasía cinematográfica en formato panorámico 16:9: un caballero medieval con armadura oscura y capa roja monta un gran dragón negro que vuela sobre Santiago de Chile. La ciudad aparece abajo y la cordillera de los Andes al fondo, bajo un cielo nublado. Imagen épica, realista y detallada.

**Intento 2 — ubicación y elementos**

> Imagen panorámica 16:9 de fantasía realista. Un dragón enorme de escamas carbón, con alas extendidas de membranas rojizas, vuela de izquierda a derecha sobre Santiago de Chile. Un único caballero con armadura metálica y capa roja cabalga sobre su lomo. La ciudad moderna ocupa el tercio inferior; detrás se distingue la cordillera de los Andes nevada. Encuadre amplio, dragón centrado y alas visibles de borde a borde; no añadir otros personajes ni criaturas.

**Intento 3 — luz, perspectiva y acabado**

> Arte conceptual cinematográfico fotorrealista, panorámico 16:9, vista aérea ligeramente elevada. En el centro, un dragón gigantesco de escamas negras, cuernos y alas membranosas extendidas atraviesa el cielo; las membranas tienen reflejos cobrizos. Un caballero medieval con armadura oscura y capa roja está claramente sentado sobre el dragón. Santiago de Chile se extiende en la parte inferior y la cordillera nevada llena el horizonte. Nubes de tormenta azul grisáceas se abren detrás del jinete dejando pasar rayos de luz cálida. Contraste dramático, atmósfera épica, escala monumental, composición legible y alto detalle. Sin texto, marcos, marcas de agua ni extremidades deformes.

### Comparación y reflexión

Como alternativa visual hecha en este proyecto, se creó [replicador-geometrico.svg](./replicador-geometrico.svg): una recreación vectorial editable con polígonos, trazos, degradados y patrones. **No es una imagen generada por IA** ni reemplaza la evidencia de los tres intentos en un generador; puede adjuntarse como ejercicio de composición geométrica y como referencia para comparar. Se puede abrir el archivo SVG en el navegador o importarlo a un editor vectorial.

Al comparar los resultados, anota cuál se acerca más a la referencia y evalúa: posición y tamaño del dragón, presencia del jinete, lectura de Santiago y los Andes, iluminación y estilo. En cada iteración se añadieron detalles sobre la composición, la ubicación, la iluminación y las restricciones para reducir ambigüedades. Completa esta sección después de generar y guardar las imágenes:

- **Mejor intento:** pendiente de seleccionar.
- **Cambios que más ayudaron:** completar tras comparar las tres imágenes.
- **Dificultades observadas:** completar según los resultados (por ejemplo, anatomía, texto accidental o edificios poco reconocibles).
- **Evidencias por adjuntar:** tres resultados de IA, imagen final elegida y captura de la referencia usada para comparar. La recreación geométrica es una evidencia adicional, no uno de esos resultados.

## Bloques 2 y 3 — Videojuego

### Descripción

- **Nombre:** Ecos de Santiago.
- **Tipo:** juego web de memoria.
- **Objetivo:** encontrar las seis parejas de símbolos con la menor cantidad de movimientos y en el menor tiempo posible.
- **Reglas:** se muestran doce cartas boca abajo. En cada turno se descubren dos. Si coinciden, quedan visibles; si no, se ocultan después de un breve momento. La partida termina al encontrar todas las parejas.
- **Controles:** clic o toque sobre las cartas; botón “Nueva partida” para reiniciar.
- **Mejora incluida:** guarda el mejor tiempo en el navegador.

### Prompt principal de programación

> Crea un juego de memoria web llamado “Ecos de Santiago” usando únicamente HTML, CSS y JavaScript, sin frameworks ni dependencias de compilación. Debe ser adaptable a móvil y escritorio y tener una interfaz cuidada, oscura y cálida, inspirada en Santiago y la cordillera. Muestra doce cartas boca abajo que forman seis parejas con símbolos accesibles; al seleccionar dos cartas, deja las parejas coincidentes visibles y vuelve a ocultar las que no coinciden tras una pausa breve. Incluye contador de movimientos, cronómetro que empieza en el primer intento, botón para reiniciar, mensaje/modal de victoria y guardado local del mejor tiempo. Usa botones accesibles por teclado, etiquetas ARIA y estados visibles de foco. Separa el proyecto en `index.html`, `styles.css` y `game.js`. Verifica que reiniciar también cancele el cronómetro y cualquier ocultamiento pendiente.

### Prompts de mejora

1. **Interfaz:** “Revisa la interfaz del juego para mejorar la jerarquía visual, el contraste, la adaptación a pantallas pequeñas y los estados de foco. Mantén las reglas actuales y evita agregar dependencias.”
2. **Lógica y pruebas:** “Comprueba los casos de interacción del juego: pareja correcta, pareja incorrecta, clic repetido, reinicio mientras dos cartas esperan ocultarse, victoria y mejor tiempo. Corrige errores sin cambiar las reglas.”
3. **Accesibilidad:** “Revisa la navegación por teclado, los nombres accesibles de las cartas y los anuncios de estado. Propón solo cambios verificables que no interfieran con el juego.”

### Archivos y pruebas

- `index.html`: estructura y contenido del juego.
- `styles.css`: presentación adaptable.
- `game.js`: barajado, turnos, cronómetro, reinicio y récord local.

Se comprobó en navegador que el tablero crea doce cartas, las parejas correctas permanecen descubiertas, las incorrectas se ocultan, el reinicio restablece los contadores y completar el tablero muestra la victoria y actualiza el mejor tiempo. La captura de la primera versión se generó en esta sesión; guárdala y adjúntala en Classroom. El enlace público todavía no está creado: requiere publicar estos archivos desde una cuenta propia.

### Publicación gratuita con GitHub Pages

1. Crea un repositorio público en GitHub y sube `index.html`, `styles.css` y `game.js` a la raíz.
2. En el repositorio, abre **Settings → Pages**.
3. En **Build and deployment**, elige **Deploy from a branch**, selecciona `main` y la carpeta `/ (root)`, y guarda.
4. Espera a que termine el despliegue. Abre la URL que aparece en esa página, prueba una partida y adjunta el enlace y una captura.

### Reflexión final

Completa después de probar y publicar el proyecto: qué cambios de la IA aceptaste o corregiste, qué error encontraste durante las pruebas, cómo lo resolviste y qué mejorarías en una siguiente versión.
